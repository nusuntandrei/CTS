package cts.andrei.gheorghisor.g1093.factory;

public enum TicketType {
	CONCERT, EVENT, MUSEUM
}
