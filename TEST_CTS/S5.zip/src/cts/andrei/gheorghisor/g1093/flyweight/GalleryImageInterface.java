package cts.andrei.gheorghisor.g1093.flyweight;

public interface GalleryImageInterface {
	public void display(GalleryImage gallery);
}
