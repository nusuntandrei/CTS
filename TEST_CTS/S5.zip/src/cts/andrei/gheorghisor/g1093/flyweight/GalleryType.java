package cts.andrei.gheorghisor.g1093.flyweight;

public enum GalleryType {
	GRID_VIEW, LIST_VIEW
}
