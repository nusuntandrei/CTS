package cts.andrei.gheorghisor.g1093.builder;

public interface RoomTypeInterface {

}
