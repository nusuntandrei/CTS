package cts.andrei.gheorghisor.g1093.builder;

public class FloorLevel implements FloorLevelInterface {

}
